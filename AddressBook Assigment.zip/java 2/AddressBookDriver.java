/**
 * Driver for the AddressBook.
 * @author Pritesh Bhole 
 * @version 15 May 2015
 */
public class AddressBookDriver
{
    public static void main(String[] args)
    {
        AddressBookGUI addressBookGUI = new AddressBookGUI();
    }
}
